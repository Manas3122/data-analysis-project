create database sql_project;
use sql_project ;
create table students (
		student_id varchar(10) primary key,
        gender varchar(10),
        age int
);

insert into students (student_id,gender,age) values
('S001', 'Male', 20),
('S002', 'Female', 19),
('S003', 'Male', 22),
('S004', 'Female', 21),
('S005', 'Male', 23),
('S006', 'Female', 20),
('S007', 'Male', 24),
('S008', 'Female', 22),
('S009', 'Male', 25),
('S010', 'Female', 23),
('S011', 'Male', 21),
('S012', 'Female', 19),
('S013', 'Male', 22),
('S014', 'Female', 20),
('S015', 'Male', 23),
('S016', 'Female', 21),
('S017', 'Male', 24),
('S018', 'Female', 22),
('S019', 'Male', 25),
('S020', 'Female', 23),
('S021', 'Male', 20),
('S022', 'Female', 19),
('S023', 'Male', 22),
('S024', 'Female', 21),
('S025', 'Male', 23),
('S026', 'Female', 20),
('S027', 'Male', 24),
('S028', 'Female', 22),
('S029', 'Male', 25),
('S030', 'Female', 23);

select * from  students;	

create table education(
		education_id int primary key,
        parent_education varchar(50));
        
insert into education(education_id , parent_education) values
(01,'Bachelor'),
(02,'High School'),
(03,'Masters'),
(04,'None'),
(05,'PhD');

select * from education;

create table student_performance(
	performance_id int auto_increment primary key,
    student_id varchar(10),
    study_hours_per_week int,
    attendance_rate decimal(5,2),
    previous_score int,
    final_score int,
    passed varchar(5),
    education_id int,
    internet_access varchar(5),
    extracurricular varchar(5),
    
    foreign key (student_id) references students(student_id),
    foreign key (education_id) references education(education_id));
    
insert into student_performance 
(student_id, study_hours_per_week, attendance_rate, previous_score, final_score, passed, education_id, internet_access, extracurricular)
values
('S001', 15, 92.50, 70, 85, 'Yes', 01, 'Yes', 'Yes'),
('S002', 10, 88.00, 65, 78, 'Yes', 02, 'No', 'No'),
('S003', 8, 75.00, 50, 60, 'No', 03, 'Yes', 'No'),
('S004', 20, 95.00, 80, 90, 'Yes', 04, 'Yes', 'Yes'),
('S005', 12, 85.00, 55, 72, 'Yes', 05, 'No', 'Yes'),
('S006', 6, 70.00, 40, 55, 'No', 01, 'Yes', 'No'),
('S007', 18, 93.00, 75, 88, 'Yes', 02, 'Yes', 'Yes'),
('S008', 9, 78.00, 60, 65, 'Yes', 03, 'No', 'No'),
('S009', 14, 82.00, 68, 80, 'Yes', 04, 'Yes', 'No'),
('S010', 11, 76.00, 52, 60, 'No', 05, 'No', 'Yes'),
('S011', 16, 90.00, 72, 85, 'Yes', 01, 'Yes', 'Yes'),
('S012', 7, 68.00, 45, 55, 'No', 02, 'No', 'No'),
('S013', 13, 84.00, 66, 78, 'Yes', 03, 'Yes', 'Yes'),
('S014', 19, 96.00, 82, 92, 'Yes', 04, 'Yes', 'Yes'),
('S015', 10, 74.00, 58, 65, 'Yes', 05, 'No', 'No'),
('S016', 8, 71.00, 49, 55, 'No', 01, 'Yes', 'No'),
('S017', 17, 89.00, 73, 86, 'Yes', 02, 'Yes', 'Yes'),
('S018', 12, 80.00, 61, 70, 'Yes', 03, 'No', 'Yes'),
('S019', 15, 91.00, 77, 88, 'Yes', 04, 'Yes', 'No'),
('S020', 9, 69.00, 46, 55, 'No', 05, 'No', 'No'),
('S021', 14, 83.00, 65, 75, 'Yes', 01, 'Yes', 'Yes'),
('S022', 11, 77.00, 53, 62, 'No', 02, 'No', 'Yes'),
('S023', 18, 94.00, 79, 90, 'Yes', 03, 'Yes', 'Yes'),
('S024', 7, 67.00, 42, 50, 'No', 04, 'No', 'No'),
('S025', 16, 88.00, 70, 82, 'Yes', 05, 'Yes', 'Yes'),
('S026', 13, 81.00, 64, 72, 'Yes', 01, 'No', 'Yes'),
('S027', 20, 97.00, 85, 95, 'Yes', 02, 'Yes', 'Yes'),
('S028', 10, 73.00, 55, 62, 'No', 03, 'No', 'No'),
('S029', 15, 86.00, 69, 80, 'Yes', 04, 'Yes', 'Yes'),
('S030', 9, 70.00, 47, 55, 'No', 05, 'No', 'No');

select * from student_performance;

select s.student_id, s.gender, e.parent_education, p.final_score
from student_performance p
join students s ON p.student_id = s.student_id
join education e ON p.education_id=e.education_id;

-- 1. Retrive all records from performance table.
select * from student_performance;

-- 2. Display the student ID and final score of all students.
select student_id, final_score
from student_performance;

-- 3. Find all students who have passed in exam.
select * from student_performance where passed = 'yes';

-- 4. List Students who have more than 70 in final exam.
select student_id, final_score from student_performance
where final_score > 70;

-- 5. Display students sorted by their final score in descending order.
select student_id, final_score from student_performance
order by final_score desc ;

-- 6. count total no. of students in dataset.
select count(distinct(student_id)) as 'Total no. of Studnets'from student_performance ;

-- 7. Find the number of stundet who passed and failed.
select passed, count(*) as student
from student_performance
group by passed
order by passed;

-- 8. Calculate the average final score of all students.
select avg(final_score) as Score
from student_performance;

-- 9. find the average final score based on internet access.
select internet_access, avg(final_score) as Avg_Score
from student_performance
group by internet_access;

Alter table education
Rename column parent_education to student_education;
select * from education;

-- 10. count the number of students in each education category.
select e.student_education, count(*) as Total_Stuendents
from student_performance p
join education e
	on p.education_id = e.education_id
group by e.student_education;

-- 11. Retrive the student_id,gender,and final_score of students who scored more than 70, by join.
select s.student_id, s.gender, p.final_score from students as s
join student_performance as p
on s.student_id = p.student_id
where p.final_score > 70
order by p.final_score desc;

-- 12. calculate the average final score for each gender.
select s.gender, avg(p.final_score) as Avg_Score
from students as s
join student_performance as p
on s.student_id = p.student_id
group by s.gender;

-- 13. Find the number of students who passed in each education category.
select e.student_education,count(*) as pass_count
from student_performance p
join education e on p.education_id = e.education_id
where p.passed = 'yes'
group by e.student_education;

-- 14. List students who have attendence greater than 80 along with their details.
select  student_id,attendance_rate from student_performance
where attendance_rate > 80;

-- 15 Categorize students as High,Medium or low perfromers based on their final score using a case statement
select student_id,final_score,
	case
		when final_score >= 75 then 'High'
        when final_score <= 50 then 'Medium'
        else 'Low'
        end as performance_level
from student_performance;

-- 16 Classify studnets as Pass or Fail using a case statement
select student_id,final_score,
	case
		when final_score >=60 then 'Pass'
        else 'Fail'
        end as Result
from student_performance;

-- 17 Find students who scored above the average final score
select * from student_performance
where final_score > (select avg(final_score) from student_performance);

-- 18. Identify the students with highest final score
select * from student_performance
where final_score = (select max(final_score)from student_performance);

-- 19. Find students whose attendence is above the average attendence.
select * from student_performance
where attendance_rate > 
	(select avg(attendance_rate) from student_performance);

-- 20. Using a CTE, find students whose scores are above the average score.
with avg_score_cte as (
	select avg(final_score) as Avg_Score
    from student_performance
)
select * from student_performance p, avg_score_cte a
where p.final_score > a.avg_score;
    
-- 21. create a cte to combine students and performance data, then filter students scoring above 60
with student_data as(
    select
		s.student_id,
        s.gender,
        p.final_score
	from students s
    join student_performance p
		on s.student_id = p.student_id
)
select * 
from student_data 
where final_score > 60;

-- 22. Rank students based on their final score in descending order
select student_id, final_score,rank()over(order by final_score desc) as Rank_Final
from student_performance;

-- 23. Rank students within each education category based on their scores.
select e.student_education, p.student_id, p.final_score,
	rank()over(partition by e.student_education
    order by p.final_score desc)as Rank_Final
from student_performance p
join education e
	on e.education_id = p.education_id;
    
-- 24. Assign a unique row number to each student based on their scores.
select 
	student_id,
    final_score,
    row_number() over (order by final_score desc) as Row_Num
from student_performance;

-- 25. Calculate the running average of final scores.
select student_id,final_score,
	avg(final_score) over (order by student_id) as running_avg
from student_performance;

